<?php
/**
 * The template for displaying Archive pages.
 *
 * Used to display archive-type pages if nothing more specific matches a query.
 * For example, puts together date-based pages if no date.php file exists.
 *
 * Learn more: http://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 */

if ( is_category() ) wp_redirect( get_term_link( get_queried_object()->slug, "category" ) );
if ( isset(get_queried_object()->slug) && is_tax("event-type", get_queried_object()->slug ) ){
	$events_page = get_option("options_module_events_page");
	$events_url = "";
	if ($events_page[0]) $events_url = get_permalink($events_page[0]);
	if ( !$events_url ) $events_url = site_url("/events/");
	wp_redirect( $events_url . "?cat=" .  get_queried_object()->slug );
}
get_header();

$catid = "";
if ( isset(get_queried_object()->term_id) ) $catid = get_queried_object()->term_id;	

	if ( have_posts() )
		the_post();
		?>
		<div class="col-lg-8 col-md-8 white">
			<div class="row">
				<div class='breadcrumbs'>
					<?php if(function_exists('bcn_display') && !is_front_page()) bcn_display();?>
				</div>
			</div>
			<h1>
		<?php if ( is_day() ) : ?>
						<?php printf( __( 'Daily archives: %s', 'govintranet' ), get_the_date() ); ?>
		<?php elseif ( is_month() ) : ?>
						<?php printf( __( 'Monthly archives: %s', 'govintranet' ), get_the_date('F Y') ); ?>
		<?php elseif ( is_year() ) : ?>
						<?php printf( __( 'Yearly archives: %s', 'govintranet' ), get_the_date('Y') ); ?>
		<?php else : ?>
				<?php
				$archiveTitle = post_type_archive_title('',false);
				if ( $archiveTitle != "" ):
					echo "<h1>".$archiveTitle."</h1>";
				else:
					the_archive_title( '<h1">', '</h1>' );
					the_archive_description( '<div class="taxonomy-description">', '</div>' );
				endif;
				?>
		<?php endif; ?>
			</h1>

		<?php
			/* Since we called the_post() above, we need to
			 * rewind the loop back to the beginning that way
			 * we can run the loop properly, in full.
			 */
			rewind_posts();
		
			/* Run the loop for the archives page to output the posts.
			 * If you want to overload this in a child theme then include a file
			 * called loop-archives.php and that will be used instead.
			 */
			 get_template_part( 'loop', 'archive' );
			 wp_reset_postdata();
		?>
		</div>

	<div class="col-lg-4 col-md-4" id="sidebar">
		<h2 class="sr-only">Sidebar</h2>
		<div id="related">
			<?php if (is_tax(array('news-update-type')) || is_post_type_archive('news-update')):
					$taxonomies=array();
					$post_type = array();
					$taxonomies[] = 'news-update-type';
					$post_type[] = 'news-update';
					$post_cat = get_terms_by_post_type( $taxonomies, $post_type);
					if ( $post_cat && count($post_cat) > 1 ){
						echo "<div class='widget-box news-update-type-terms'><h3 class='widget-title'>";
						_ex('Update categories','A title for the news update category','govintranet');
						echo "</h3>";
						echo "<p class='taglisting news'>";
						foreach($post_cat as $cat){
							if ( $cat->name && ( $cat->term_id != $catid ) ){
								$newname = str_replace(" ", "&nbsp;", $cat->name );
								echo "<span><a class='wptag t".$cat->term_id."' href='".get_term_link($cat->slug, 'news-update-type')."'>".$newname."</a></span> ";
							}
						}
						echo "</p></div>";
					}
				 dynamic_sidebar('news-landing-widget-area');  
				 endif;
				 ?>
				 <?php 
				if (is_tax(array('blog-category')) || is_post_type_archive('blog')):
					$taxonomies=array();
					$post_type = array();
					$taxonomies[] = 'blog-category';
					$post_type[] = 'blog';
					$post_cat = get_terms_by_post_type( $taxonomies, $post_type);
					if ( $post_cat && count($post_cat) > 1 ){
						echo "<div class='widget-box blog-category-terms'><h3 class='widget-title'>";
						_ex('Categories','A title for the blog category','govintranet');
						echo "</h3>";
						echo "<p class='taglisting news'>";
						foreach($post_cat as $cat){
							if ( $cat->name && ( $cat->term_id != $catid ) ){
								$newname = str_replace(" ", "&nbsp;", $cat->name );
								echo "<span><a class='wptag t".$cat->term_id."' href='".get_term_link($cat->slug, 'blog-category')."'>".$newname."</a></span> ";
							}
						}
						echo "</p></div>";
					}
					dynamic_sidebar('blog-landing-widget-area');  
				 endif;
				 ?>
		</div>
	</div>

<?php 
get_footer(); 