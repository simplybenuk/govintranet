jQuery(document).ready(function() {
	
	jQuery('.match-height').matchHeight();
	
}); 
