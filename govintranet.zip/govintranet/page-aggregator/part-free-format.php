	<?php
	global $post;
	global $freeformat;
	echo "<div class='widget-box'>";
	echo $freeformat;
	echo "</div>";
	wp_reset_postdata();
	?>			